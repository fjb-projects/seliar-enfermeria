import { describe, expect, it } from "vitest";
import {
  createEfaEpisodesService,
  type EfaEpisodeAuditRecord,
  type EfaEpisodeNoticeRecord,
  type EfaEpisodeRecord,
  type EfaEpisodeTransaction,
} from "./efa-episodes.server";
import type {
  EfaCommunicationRecord,
  EfaCommunicationOperationRecord,
} from "./efa-communications.server";

const opened = new Date("2026-10-06T08:00:00.000Z");
const eventTime = new Date("2026-10-06T09:30:00.000Z");
const owner = "owner";
const admin = "admin";
const guardId = "guard-open";

function createStore() {
  const actors = new Map<string, { isActive: boolean; roles: Array<"efa" | "admin"> }>([
    [owner, { isActive: true, roles: ["efa"] as Array<"efa" | "admin"> }],
    [admin, { isActive: true, roles: ["admin"] as Array<"efa" | "admin"> }],
    ["revoked", { isActive: true, roles: [] as Array<"efa" | "admin"> }],
    ["disabled", { isActive: false, roles: ["efa"] as Array<"efa" | "admin"> }],
  ]);
  const guards = new Map([
    [guardId, { id: guardId, ownerUserId: owner, startedAt: opened, endedAt: null }],
    [
      "guard-closed",
      {
        id: "guard-closed",
        ownerUserId: owner,
        startedAt: opened,
        endedAt: new Date("2026-10-06T18:00:00.000Z"),
      },
    ],
    ["guard-other", { id: "guard-other", ownerUserId: "other", startedAt: opened, endedAt: null }],
  ]);
  const episodes: EfaEpisodeRecord[] = [];
  const audits: EfaEpisodeAuditRecord[] = [];
  const notices: EfaEpisodeNoticeRecord[] = [];
  const communications: EfaCommunicationRecord[] = [];
  const communicationAudits: Array<Record<string, unknown>> = [];
  const communicationOperations: EfaCommunicationOperationRecord[] = [];
  const operationLookup: Array<{
    id: string;
    episodeId: string;
    actorUserId: string;
    clientOperationId: string;
    action: "created" | "updated" | "closed" | "cancelled" | "reactivated";
    requestHash: string;
    appliedVersion: number;
    changed: boolean;
  }> = [];
  let forcedCreationMisses = 0;
  let activeCommunication = false;
  let activeDispatch = false;
  let transactionTail = Promise.resolve();
  const guardLocks: string[] = [];
  const episodeLocks: string[] = [];
  let auditNumber = 0;
  let noticeNumber = 0;
  let failCommunicationReceipt = false;
  const detachEpisode = (episode: EfaEpisodeRecord): EfaEpisodeRecord => ({
    ...episode,
    eventAt: new Date(episode.eventAt),
    closedAt: episode.closedAt ? new Date(episode.closedAt) : null,
    cancelledAt: episode.cancelledAt ? new Date(episode.cancelledAt) : null,
    createdAt: new Date(episode.createdAt),
    updatedAt: new Date(episode.updatedAt),
  });
  const tx = {
    communicationCreation: {
      async findActor(userId: string) {
        return actors.get(userId) ?? null;
      },
      async findEpisodeForCommunication(id: string) {
        const episode = episodes.find((item) => item.id === id);
        return episode
          ? { id: episode.id, ownerUserId: episode.ownerUserId, cancelledAt: episode.cancelledAt }
          : null;
      },
      async lockCreationKey() {},
      async findCommunicationByCreationKey(userId: string, key: string) {
        return (
          communications.find(
            (item) => item.ownerUserId === userId && item.clientCreationKey === key,
          ) ?? null
        );
      },
      async findCreationOperation(id: string, key: string) {
        return (
          communicationOperations.find(
            (item) => item.communicationId === id && item.clientOperationId === key,
          ) ?? null
        );
      },
      async insertCommunication(
        input: Omit<
          EfaCommunicationRecord,
          | "version"
          | "createdAt"
          | "updatedAt"
          | "finalizedAt"
          | "cancelledAt"
          | "cancelledFromState"
        >,
      ) {
        const now = new Date("2026-10-06T10:00:00.000Z");
        communications.push({
          ...input,
          version: 1,
          createdAt: now,
          updatedAt: now,
          finalizedAt: null,
          cancelledAt: null,
          cancelledFromState: null,
        });
      },
      async appendCreationAudit(input: Record<string, unknown>) {
        communicationAudits.push(input);
        return `communication-audit-${communicationAudits.length}`;
      },
      async insertCreationOperation(input: Omit<EfaCommunicationOperationRecord, "id">) {
        if (failCommunicationReceipt) {
          failCommunicationReceipt = false;
          throw new Error("communication-receipt-fault");
        }
        communicationOperations.push({
          ...input,
          id: `communication-operation-${communicationOperations.length + 1}`,
        });
      },
      async findCommunication(id: string) {
        return communications.find((item) => item.id === id) ?? null;
      },
    },
    async findActor(userId: string) {
      return actors.get(userId) ?? null;
    },
    async findGuard(id: string, lock = false) {
      if (lock) guardLocks.push(id);
      return guards.get(id) ?? null;
    },
    async listEpisodes(ownerUserId: string | null) {
      return episodes
        .filter((episode) => !ownerUserId || episode.ownerUserId === ownerUserId)
        .map(detachEpisode);
    },
    async findEpisode(id: string, lock = false) {
      if (lock) episodeLocks.push(id);
      const episode = episodes.find((item) => item.id === id);
      return episode ? detachEpisode(episode) : null;
    },
    async hasNonCancelledCommunication() {
      return activeCommunication;
    },
    async hasNonCancelledDispatch() {
      return activeDispatch;
    },
    async currentTimestamp() {
      return new Date("2026-10-07T11:00:00.000Z");
    },
    async findEpisodeByCreationKey(userId: string, key: string) {
      if (forcedCreationMisses > 0) {
        forcedCreationMisses -= 1;
        return null;
      }
      const episode = episodes.find(
        (item) => item.ownerUserId === userId && item.clientCreationKey === key,
      );
      return episode ? detachEpisode(episode) : null;
    },
    async findOperation(episodeId: string, clientOperationId: string) {
      return (
        operationLookup.find(
          (operation) =>
            operation.episodeId === episodeId && operation.clientOperationId === clientOperationId,
        ) ?? null
      );
    },
    async insertEpisode(input: Omit<EfaEpisodeRecord, "version" | "createdAt" | "updatedAt">) {
      const now = new Date("2026-10-06T10:00:00.000Z");
      episodes.push({ ...input, version: 1, createdAt: now, updatedAt: now });
    },
    async updateEpisode(
      id: string,
      expectedVersion: number,
      next: Pick<
        EfaEpisodeRecord,
        | "eventAt"
        | "motive"
        | "address"
        | "interventionNumber"
        | "state"
        | "closedAt"
        | "cancelledAt"
        | "cancelledFromState"
        | "version"
      >,
    ) {
      const episode = episodes.find((item) => item.id === id);
      if (!episode || episode.version !== expectedVersion)
        throw new Error("episode-version-conflict");
      Object.assign(episode, next, { updatedAt: new Date("2026-10-06T11:00:00.000Z") });
    },
    async appendAudit(input: Parameters<EfaEpisodeTransaction["appendAudit"]>[0]) {
      auditNumber += 1;
      const id = `audit-${auditNumber}`;
      audits.push({ ...input, id, occurredAt: new Date("2026-10-06T10:00:00.000Z") });
      return id;
    },
    async insertOperation(input: Omit<(typeof operationLookup)[number], "id">) {
      operationLookup.push({ ...input, id: `op-${operationLookup.length + 1}` });
    },
    async appendNotice(input: Parameters<EfaEpisodeTransaction["appendNotice"]>[0]) {
      noticeNumber += 1;
      notices.push({
        ...input,
        id: `notice-${noticeNumber}`,
        createdAt: new Date("2026-10-06T11:00:00.000Z"),
        readAt: null,
      });
    },
    async listAudits(episodeId: string) {
      return audits.filter((audit) => audit.episodeId === episodeId);
    },
    async listNotices(recipientUserId: string) {
      return notices.filter((notice) => notice.recipientUserId === recipientUserId);
    },
    async markNoticeRead(noticeId: string, recipientUserId: string) {
      const notice = notices.find(
        (item) => item.id === noticeId && item.recipientUserId === recipientUserId,
      );
      if (!notice) return null;
      notice.readAt ??= new Date("2026-10-06T12:00:00.000Z");
      return notice;
    },
  } satisfies EfaEpisodeTransaction;
  return {
    store: {
      async transaction<T>(work: (value: EfaEpisodeTransaction) => Promise<T>) {
        const previous = transactionTail;
        let release!: () => void;
        transactionTail = new Promise<void>((resolve) => {
          release = resolve;
        });
        await previous;
        const lengths = [
          episodes.length,
          audits.length,
          operationLookup.length,
          communications.length,
          communicationAudits.length,
          communicationOperations.length,
        ];
        try {
          return await work(tx);
        } catch (error) {
          episodes.length = lengths[0]!;
          audits.length = lengths[1]!;
          operationLookup.length = lengths[2]!;
          communications.length = lengths[3]!;
          communicationAudits.length = lengths[4]!;
          communicationOperations.length = lengths[5]!;
          throw error;
        } finally {
          release();
        }
      },
    },
    episodes,
    audits,
    notices,
    operationLookup,
    communications,
    communicationAudits,
    communicationOperations,
    guardLocks,
    episodeLocks,
    guards,
    setForcedCreationMisses(value: number) {
      forcedCreationMisses = value;
    },
    setActiveChildren(communication: boolean, dispatch: boolean) {
      activeCommunication = communication;
      activeDispatch = dispatch;
    },
    setRoles(userId: string, roles: Array<"efa" | "admin">) {
      const actor = actors.get(userId)!;
      actors.set(userId, { ...actor, roles });
    },
    closeGuard(id: string) {
      guards.get(id)!.endedAt = new Date("2026-10-06T18:00:00.000Z");
    },
    failNextCommunicationReceipt() {
      failCommunicationReceipt = true;
    },
  };
}

const createInput = (overrides: Record<string, unknown> = {}) => ({
  clientCreationKey: "11111111-1111-4111-8111-111111111111",
  guardId,
  eventAt: "2026-10-06T09:30:00.000Z",
  motive: "  Traslado de paciente  ",
  address: "  Calle 123, piso 2  ",
  interventionNumber: "  00073  ",
  ...overrides,
});

describe("EFA episode draft persistence", () => {
  it("creates an incoming first-call draft with a verifiable immutable receipt", async () => {
    const db = createStore();
    const service = createEfaEpisodesService(db.store, { newId: () => "episode-1" });
    const result = await service.create(
      owner,
      createInput({
        childCreateKey: "22222222-2222-4222-8222-222222222222",
        direction: "incoming",
      }),
    );

    expect(result.initialCall).toMatchObject({
      communication: {
        episodeId: result.episode.id,
        clientCreationKey: "22222222-2222-4222-8222-222222222222",
        direction: "incoming",
        startedAt: null,
        endedAt: null,
        priority: null,
        state: "draft",
      },
      creationReceipt: {
        episodeId: result.episode.id,
        clientCreationKey: "22222222-2222-4222-8222-222222222222",
        action: "created",
        appliedVersion: 1,
        changed: true,
      },
    });
  });

  it("replays the original first-call receipt after the call and episode change", async () => {
    const db = createStore();
    const service = createEfaEpisodesService(db.store, {
      newId: (() => {
        let id = 0;
        return () => `record-${++id}`;
      })(),
    });
    const input = createInput({
      childCreateKey: "22222222-2222-4222-8222-222222222222",
      direction: "incoming",
    });
    const first = await service.create(owner, input);
    const call = db.communications[0]!;
    Object.assign(call, {
      direction: "outgoing",
      startedAt: new Date("2026-10-06T12:00:00.000Z"),
      state: "finalized",
      version: 2,
    });
    Object.assign(db.episodes[0]!, {
      cancelledAt: new Date("2026-10-07T12:00:00.000Z"),
      state: "closed",
    });

    const replayed = await service.create(owner, input);
    expect(replayed.initialCall?.creationReceipt).toEqual(first.initialCall?.creationReceipt);
    expect(replayed.initialCall?.replayed).toBe(true);
    expect(replayed.initialCall?.communication).toMatchObject({
      direction: "outgoing",
      state: "finalized",
      version: 2,
    });
  });

  it("rolls back episode, call, audits and receipts when the call receipt write fails", async () => {
    const db = createStore();
    const service = createEfaEpisodesService(db.store, { newId: () => "episode-1" });
    db.failNextCommunicationReceipt();

    await expect(
      service.create(
        owner,
        createInput({
          childCreateKey: "22222222-2222-4222-8222-222222222222",
          direction: "incoming",
        }),
      ),
    ).rejects.toThrow("communication-receipt-fault");
    expect(db.episodes).toHaveLength(0);
    expect(db.audits).toHaveLength(0);
    expect(db.operationLookup).toHaveLength(0);
    expect(db.communications).toHaveLength(0);
    expect(db.communicationAudits).toHaveLength(0);
    expect(db.communicationOperations).toHaveLength(0);
  });

  it("rejects a child key already bound to another episode and rolls back the new episode", async () => {
    const db = createStore();
    const service = createEfaEpisodesService(
      db.store,
      (() => {
        let id = 0;
        return { newId: () => `record-${++id}` };
      })(),
    );
    const childCreateKey = "22222222-2222-4222-8222-222222222222";
    await service.create(owner, createInput({ childCreateKey, direction: "incoming" }));

    await expect(
      service.create(
        owner,
        createInput({
          clientCreationKey: "33333333-3333-4333-8333-333333333333",
          childCreateKey,
          direction: "incoming",
        }),
      ),
    ).rejects.toThrow("La clave de llamada ya pertenece a otro episodio o usuario.");
    expect(db.episodes).toHaveLength(1);
    expect(db.communications).toHaveLength(1);
  });

  it("stores event time separately from capture time and returns a safe caller-bound DTO", async () => {
    const db = createStore();
    const service = createEfaEpisodesService(db.store, { newId: () => "episode-1" });
    const result = await service.create(owner, createInput());
    const draft = result.episode;
    expect(draft).toMatchObject({
      id: "episode-1",
      ownerUserId: owner,
      originGuardId: guardId,
      eventAt: eventTime.toISOString(),
      motive: "Traslado de paciente",
      address: "Calle 123, piso 2",
      interventionNumber: "00073",
      state: "draft",
      version: 1,
      canEdit: true,
    });
    expect(draft.createdAt).not.toBe(draft.eventAt);
    expect(db.audits[0]).toMatchObject({ action: "created", versionBefore: null, versionAfter: 1 });
    expect(result.operation).toMatchObject({
      action: "created",
      appliedVersion: 1,
      changed: true,
      replayed: false,
    });
    expect(JSON.stringify(draft)).not.toMatch(/operationId|password|credential|token/i);
    expect(JSON.stringify(db.operationLookup)).not.toContain("Calle 123");
  });

  it("accepts a time-only draft and allows clearing both optional identifiers", async () => {
    const db = createStore();
    const service = createEfaEpisodesService(db.store, { newId: () => "episode-1" });
    const created = await service.create(
      owner,
      createInput({ motive: null, address: null, interventionNumber: null }),
    );
    expect(created.episode).toMatchObject({
      motive: null,
      address: null,
      interventionNumber: null,
    });

    const updated = await service.update(owner, {
      episodeId: created.episode.id,
      expectedVersion: 1,
      operationId: "77777777-7777-4777-8777-777777777777",
      eventAt: "2026-10-06T11:00:00.000Z",
      motive: null,
      address: null,
      interventionNumber: null,
    });
    expect(updated.episode).toMatchObject({ version: 2, motive: null, address: null });
  });

  it("rejects inactive actors, revoked editors, and foreign or closed guards without audit", async () => {
    const db = createStore();
    const service = createEfaEpisodesService(db.store);
    await expect(service.create("disabled", createInput())).rejects.toThrow(/inactiva/i);
    await expect(service.create("revoked", createInput())).rejects.toThrow(/EFA/i);
    await expect(service.create(owner, createInput({ guardId: "guard-other" }))).rejects.toThrow(
      /propia/i,
    );
    await expect(service.create(owner, createInput({ guardId: "guard-closed" }))).rejects.toThrow(
      /abierta/i,
    );
    expect(db.episodes).toHaveLength(0);
    expect(db.audits).toHaveLength(0);
  });

  it("allows owner history after EFA revocation but blocks edits; admin can read all", async () => {
    const db = createStore();
    const service = createEfaEpisodesService(db.store, { newId: () => "episode-1" });
    await service.create(owner, createInput());
    db.setRoles(owner, []);
    await expect(service.list(owner)).resolves.toMatchObject([{ canEdit: false }]);
    await expect(service.get(owner, "episode-1")).resolves.toMatchObject({
      ownerUserId: owner,
      canEdit: false,
    });
    await expect(
      service.update(owner, {
        episodeId: "episode-1",
        expectedVersion: 1,
        operationId: "55555555-5555-4555-8555-555555555555",
        eventAt: "2026-10-06T10:00:00.000Z",
        motive: null,
        address: null,
        interventionNumber: null,
      }),
    ).rejects.toThrow(/EFA/i);
    await expect(service.list(admin)).resolves.toHaveLength(1);
  });

  it("supports idempotent creation retries, including after the origin guard closes", async () => {
    const db = createStore();
    const service = createEfaEpisodesService(db.store, { newId: () => "episode-1" });
    const first = await service.create(owner, createInput());
    const second = await service.create(owner, createInput());
    expect(second.episode.id).toBe(first.episode.id);
    expect(second.operation).toMatchObject({ appliedVersion: 1, replayed: true });
    expect(db.episodes).toHaveLength(1);
    expect(db.audits).toHaveLength(1);
    await expect(service.create(owner, createInput({ motive: "Otro episodio" }))).rejects.toThrow(
      /identidad/i,
    );
    expect(db.episodes).toHaveLength(1);
    expect(db.audits).toHaveLength(1);
  });

  it("updates a closed-guard draft optimistically and notifies the original owner for admin edits", async () => {
    const db = createStore();
    const service = createEfaEpisodesService(db.store, { newId: () => "episode-1" });
    await service.create(owner, createInput());
    db.closeGuard(guardId);
    const next = {
      episodeId: "episode-1",
      expectedVersion: 1,
      operationId: "22222222-2222-4222-8222-222222222222",
      eventAt: "2026-10-06T10:15:00.000Z",
      motive: "Actualizado",
      address: "Calle 123, piso 2",
      interventionNumber: "00073",
    };
    const concurrent = await Promise.all([
      service.update(admin, next),
      service.update(admin, next),
    ]);
    expect(concurrent).toEqual(
      expect.arrayContaining([
        expect.objectContaining({ operation: expect.objectContaining({ appliedVersion: 2 }) }),
        expect.objectContaining({
          operation: expect.objectContaining({ appliedVersion: 2, replayed: true }),
        }),
      ]),
    );
    expect(db.episodeLocks).toEqual(["episode-1", "episode-1"]);
    expect(db.audits).toHaveLength(2);
    expect(db.audits[1]).toMatchObject({
      actorUserId: admin,
      action: "updated",
      versionBefore: 1,
      versionAfter: 2,
      beforeState: {
        eventAt: "2026-10-06T09:30:00.000Z",
        motive: "Traslado de paciente",
        address: "Calle 123, piso 2",
        interventionNumber: "00073",
        state: "draft",
      },
      afterState: {
        eventAt: "2026-10-06T10:15:00.000Z",
        motive: "Actualizado",
        address: "Calle 123, piso 2",
        interventionNumber: "00073",
        state: "draft",
      },
    });
    expect(db.notices).toHaveLength(1);
    expect(db.notices[0]).toMatchObject({
      episodeId: "episode-1",
      recipientUserId: owner,
      auditId: expect.any(String),
    });
    await expect(service.update(admin, next)).resolves.toMatchObject({
      episode: { version: 2 },
      operation: { appliedVersion: 2, replayed: true },
    });
    expect(db.audits).toHaveLength(2);
    expect(db.notices).toHaveLength(1);
    await expect(
      service.update(owner, {
        ...next,
        expectedVersion: 1,
        operationId: "33333333-3333-4333-8333-333333333333",
      }),
    ).rejects.toThrow(/cambió/i);
    expect(db.audits).toHaveLength(2);
  });

  it("does not create redundant notices for self-edits and never exposes foreign records to non-admins", async () => {
    const db = createStore();
    const service = createEfaEpisodesService(db.store, { newId: () => "episode-1" });
    await service.create(owner, createInput());
    db.closeGuard(guardId);
    const result = await service.update(owner, {
      episodeId: "episode-1",
      expectedVersion: 1,
      operationId: "44444444-4444-4444-8444-444444444444",
      eventAt: "2026-10-06T10:15:00.000Z",
      motive: null,
      address: null,
      interventionNumber: null,
    });
    expect(result).toMatchObject({
      episode: { version: 2, canEdit: true },
      operation: { changed: true },
    });
    expect(db.audits[1]).toMatchObject({
      actorUserId: owner,
      action: "updated",
      versionBefore: 1,
      versionAfter: 2,
      beforeState: {
        eventAt: "2026-10-06T09:30:00.000Z",
        motive: "Traslado de paciente",
        address: "Calle 123, piso 2",
        interventionNumber: "00073",
        state: "draft",
      },
      afterState: {
        eventAt: "2026-10-06T10:15:00.000Z",
        motive: null,
        address: null,
        interventionNumber: null,
        state: "draft",
      },
    });
    expect(db.notices).toHaveLength(0);
    await expect(service.get("revoked", "episode-1")).rejects.toThrow(/encontró/i);
    await expect(service.get(admin, "episode-1")).resolves.toMatchObject({ address: null });
  });

  it("records stable no-op receipts without fabricating audit versions or notices", async () => {
    const db = createStore();
    const service = createEfaEpisodesService(db.store, { newId: () => "episode-1" });
    const created = await service.create(owner, createInput());
    const noop = {
      episodeId: "episode-1",
      expectedVersion: 1,
      operationId: "66666666-6666-4666-8666-666666666666",
      eventAt: "2026-10-06T09:30:00.000Z",
      motive: "Traslado de paciente",
      address: "Calle 123, piso 2",
      interventionNumber: "00073",
    };
    const first = await service.update(owner, noop);
    expect(first).toMatchObject({
      episode: { version: 1 },
      operation: { changed: false, appliedVersion: 1 },
    });
    await service.update(owner, {
      ...noop,
      expectedVersion: 1,
      operationId: "77777777-7777-4777-8777-777777777777",
      motive: "Nuevo motivo",
    });
    const retry = await service.update(owner, noop);
    expect(retry).toMatchObject({
      episode: { version: 2, motive: "Nuevo motivo" },
      operation: { changed: false, appliedVersion: 1, replayed: true },
    });
    expect(db.audits).toHaveLength(2);
    expect(db.notices).toHaveLength(0);
    expect(db.operationLookup).toHaveLength(3);
    await expect(service.update(owner, { ...noop, motive: "Payload distinto" })).rejects.toThrow(
      /identidad/i,
    );
    expect(db.operationLookup).toHaveLength(3);
    expect(created.operation.appliedVersion).toBe(1);
  });

  it("replays a creation after closure and later edits using the receipt fingerprint", async () => {
    const db = createStore();
    const service = createEfaEpisodesService(db.store, { newId: () => "episode-1" });
    const original = createInput();
    const created = await service.create(owner, original);
    db.closeGuard(guardId);
    await service.update(owner, {
      episodeId: created.episode.id,
      expectedVersion: 1,
      operationId: "88888888-8888-4888-8888-888888888888",
      eventAt: "2026-10-06T10:15:00.000Z",
      motive: "Actualizado",
      address: "Calle 123, piso 2",
      interventionNumber: "00073",
    });
    const retry = await service.create(owner, original);
    expect(retry).toMatchObject({
      episode: { id: created.episode.id, version: 2, motive: "Actualizado" },
      operation: { appliedVersion: 1, replayed: true },
    });
    expect(db.episodes).toHaveLength(1);
  });

  it("rechecks creation identity after acquiring the origin guard lock", async () => {
    const db = createStore();
    const service = createEfaEpisodesService(db.store, { newId: () => "episode-1" });
    db.setForcedCreationMisses(3);
    const results = await Promise.all([
      service.create(owner, createInput()),
      service.create(owner, createInput()),
    ]);
    expect(results.map((result) => result.episode.id)).toEqual(["episode-1", "episode-1"]);
    expect(db.episodes).toHaveLength(1);
    expect(db.audits).toHaveLength(1);
    expect(db.operationLookup).toHaveLength(1);
    expect(db.guardLocks).toEqual([guardId, guardId]);
  });

  it("closes the episode independently and replays without changing guard state", async () => {
    const db = createStore();
    const service = createEfaEpisodesService(db.store, { newId: () => "episode-1" });
    await service.create(owner, createInput());
    const request = {
      episodeId: "episode-1",
      expectedVersion: 1,
      operationId: "bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb",
    };

    const first = await service.close(owner, request);

    expect(first).toMatchObject({
      episode: { state: "closed", version: 2, canEdit: true },
      operation: { id: request.operationId, action: "closed", appliedVersion: 2, changed: true },
    });
    expect(first.episode.closedAt).toBeTruthy();
    expect(db.audits[1]).toMatchObject({
      actorUserId: owner,
      action: "closed",
      versionBefore: 1,
      versionAfter: 2,
      beforeState: { state: "draft", closedAt: null },
      afterState: { state: "closed", closedAt: first.episode.closedAt },
    });
    expect(db.guards.get(guardId)?.endedAt).toBeNull();

    const replay = await service.close(owner, request);
    expect(replay).toMatchObject({
      episode: { state: "closed", version: 2, closedAt: first.episode.closedAt },
      operation: { appliedVersion: 2, changed: true, replayed: true },
    });
    const noChange = await service.close(owner, {
      ...request,
      expectedVersion: 2,
      operationId: "cccccccc-cccc-4ccc-8ccc-cccccccccccc",
    });
    expect(noChange).toMatchObject({
      episode: { state: "closed", version: 2, closedAt: first.episode.closedAt },
      operation: { appliedVersion: 2, changed: false, replayed: false },
    });
    expect(db.audits).toHaveLength(2);
    expect(db.notices).toHaveLength(0);
    await expect(service.close(owner, { ...request, expectedVersion: 2 })).rejects.toThrow(
      /identidad/i,
    );
  });

  it("keeps closure state and server timestamp through administrator corrections", async () => {
    const db = createStore();
    const service = createEfaEpisodesService(db.store, { newId: () => "episode-1" });
    await service.create(owner, createInput());
    const closure = await service.close(admin, {
      episodeId: "episode-1",
      expectedVersion: 1,
      operationId: "dddddddd-dddd-4ddd-8ddd-dddddddddddd",
    });
    const closedAt = closure.episode.closedAt;
    expect(closure).toMatchObject({ episode: { ownerUserId: owner, state: "closed", version: 2 } });
    expect(db.audits[1]).toMatchObject({ actorUserId: admin, action: "closed" });
    expect(db.notices).toEqual([
      expect.objectContaining({ recipientUserId: owner, auditId: db.audits[1]!.id }),
    ]);

    const correction = await service.update(admin, {
      episodeId: "episode-1",
      expectedVersion: 2,
      operationId: "eeeeeeee-eeee-4eee-8eee-eeeeeeeeeeee",
      eventAt: "2026-10-06T12:15:00.000Z",
      motive: "Corrección posterior al cierre",
      address: "Calle 123, piso 2",
      interventionNumber: "00073",
    });
    expect(correction.episode).toMatchObject({
      ownerUserId: owner,
      state: "closed",
      closedAt,
      version: 3,
    });
    expect(db.audits[2]).toMatchObject({
      action: "updated",
      beforeState: { state: "closed", closedAt },
      afterState: { state: "closed", closedAt },
    });
    expect(db.notices).toHaveLength(2);
    expect(db.guards.get(guardId)?.endedAt).toBeNull();
  });

  it("rejects revoked editors and stale close versions without audit or notices", async () => {
    const db = createStore();
    const service = createEfaEpisodesService(db.store, { newId: () => "episode-1" });
    await service.create(owner, createInput());
    const input = {
      episodeId: "episode-1",
      expectedVersion: 1,
      operationId: "ffffffff-ffff-4fff-8fff-ffffffffffff",
    };
    await expect(service.close("revoked", input)).rejects.toThrow(/EFA/i);
    await expect(service.close(admin, { ...input, expectedVersion: 2 })).rejects.toThrow(/cambió/i);
    expect(db.episodes[0]?.state).toBe("draft");
    expect(db.audits).toHaveLength(1);
    expect(db.notices).toHaveLength(0);
  });

  it("cancels an episode without erasing closure state and restores it on reactivation", async () => {
    const db = createStore();
    const service = createEfaEpisodesService(db.store, { newId: () => "episode-1" });
    await service.create(owner, createInput());
    const closed = await service.close(owner, {
      episodeId: "episode-1",
      expectedVersion: 1,
      operationId: "dddddddd-dddd-4ddd-8ddd-dddddddddddd",
    });
    const closedAt = closed.episode.closedAt;
    const cancelled = await service.cancel(admin, {
      episodeId: "episode-1",
      expectedVersion: 2,
      operationId: "11111111-2222-4222-8222-222222222222",
    });
    expect(cancelled.episode).toMatchObject({
      state: "closed",
      closedAt,
      cancelledAt: expect.any(String),
      cancelledFromState: "closed",
      canEdit: false,
      canManage: true,
      version: 3,
    });
    expect(db.audits[2]).toMatchObject({
      actorUserId: admin,
      action: "cancelled",
      versionBefore: 2,
      versionAfter: 3,
      beforeState: { state: "closed", closedAt, cancelledAt: null },
      afterState: { state: "closed", closedAt, cancelledFromState: "closed" },
    });
    expect(db.notices.at(-1)).toMatchObject({ recipientUserId: owner });
    const reactivated = await service.reactivate(admin, {
      episodeId: "episode-1",
      expectedVersion: 3,
      operationId: "22222222-3333-4333-8333-333333333333",
    });
    expect(reactivated.episode).toMatchObject({
      state: "closed",
      closedAt,
      cancelledAt: null,
      cancelledFromState: null,
      version: 4,
    });
    expect(db.audits[3]).toMatchObject({ action: "reactivated", actorUserId: admin });
  });

  it("rejects episode cancellation when any non-cancelled call or dispatch remains", async () => {
    const db = createStore();
    const service = createEfaEpisodesService(db.store, { newId: () => "episode-1" });
    await service.create(owner, createInput());
    db.setActiveChildren(true, false);
    await expect(
      service.cancel(owner, {
        episodeId: "episode-1",
        expectedVersion: 1,
        operationId: "33333333-4444-4444-8444-444444444444",
      }),
    ).rejects.toThrow(/comunicación|llamada/i);
    db.setActiveChildren(false, true);
    await expect(
      service.cancel(owner, {
        episodeId: "episode-1",
        expectedVersion: 1,
        operationId: "44444444-5555-4555-8555-555555555555",
      }),
    ).rejects.toThrow(/despachos/i);
    expect(db.episodeLocks).toContain("episode-1");
  });

  it("returns append-only history only to the owner or an administrator", async () => {
    const db = createStore();
    const service = createEfaEpisodesService(db.store, { newId: () => "episode-1" });
    await service.create(owner, createInput());
    await service.update(owner, {
      episodeId: "episode-1",
      expectedVersion: 1,
      operationId: "99999999-9999-4999-8999-999999999999",
      eventAt: "2026-10-06T10:15:00.000Z",
      motive: "Cambio de prioridad",
      address: "Calle 123, piso 2",
      interventionNumber: "00073",
    });

    db.setRoles(owner, []);
    const history = await service.history(owner, "episode-1");
    expect(history).toEqual([
      expect.objectContaining({
        action: "created",
        versionBefore: null,
        versionAfter: 1,
        beforeState: null,
        afterState: expect.objectContaining({ motive: "Traslado de paciente" }),
      }),
      expect.objectContaining({
        action: "updated",
        versionBefore: 1,
        versionAfter: 2,
        beforeState: expect.objectContaining({ motive: "Traslado de paciente" }),
        afterState: expect.objectContaining({ motive: "Cambio de prioridad" }),
      }),
    ]);
    await expect(service.history("admin", "episode-1")).resolves.toHaveLength(2);
    await expect(service.history(owner, "foreign-episode")).rejects.toThrow(/encontró/i);
  });

  it("lists correction notices only for their active recipient and acknowledges them idempotently", async () => {
    const db = createStore();
    const service = createEfaEpisodesService(db.store, { newId: () => "episode-1" });
    await service.create(owner, createInput());
    await service.update(admin, {
      episodeId: "episode-1",
      expectedVersion: 1,
      operationId: "aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa",
      eventAt: "2026-10-06T10:15:00.000Z",
      motive: "Ajuste administrativo",
      address: "Calle 123, piso 2",
      interventionNumber: "00073",
    });
    const noticeId = db.notices[0]!.id;
    db.setRoles(owner, []);
    const notice = await service.listNotices("owner");
    expect(notice).toEqual([
      expect.objectContaining({ id: noticeId, episodeId: "episode-1", readAt: null }),
    ]);
    expect(JSON.stringify(notice)).not.toMatch(/address|Ajuste administrativo|Calle 123/i);
    await expect(service.listNotices("admin")).resolves.toEqual([]);
    await expect(service.markNoticeRead("admin", noticeId)).rejects.toThrow(/encontró/i);

    const first = await service.markNoticeRead("owner", noticeId);
    const repeated = await service.markNoticeRead("owner", noticeId);
    expect(first.readAt).toBeTruthy();
    expect(repeated.readAt).toBe(first.readAt);
    expect(db.notices).toHaveLength(1);
    expect(db.audits).toHaveLength(2);
  });
});
